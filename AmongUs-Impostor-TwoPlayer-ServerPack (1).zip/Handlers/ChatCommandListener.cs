using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using Impostor.Api.Events;
using Impostor.Api.Events.Player;
using Impostor.Api.Games;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TwoPlayerImmortal.Configuration;

namespace TwoPlayerImmortal.Handlers
{
    public class ChatCommandListener : IEventListener
    {
        private readonly ILogger<ChatCommandListener> _logger;
        private readonly IOptionsMonitor<PluginConfig> _config;
        public static readonly ConcurrentDictionary<string, bool> SoloModeLobbies = new();

        public ChatCommandListener(ILogger<ChatCommandListener> logger, IOptionsMonitor<PluginConfig> config)
        {
            _logger = logger;
            _config = config;
        }

        [EventListener]
        public async ValueTask OnPlayerChat(IPlayerChatEvent e)
        {
            var cfg = _config.CurrentValue;
            string msg = e.Message?.Trim() ?? string.Empty;
            if (!msg.StartsWith(cfg.SoloCommandPrefix)) return;

            e.IsCancelled = true; // Hide command from lobby chat
            var player = e.PlayerControl;
            if (cfg.HostOnlyCommands && (player.ClientPlayer == null || !player.ClientPlayer.IsHost))
            {
                await player.SendChatAsync("[Server] Permission denied: Only host can run commands.");
                return;
            }

            string[] parts = msg.Substring(cfg.SoloCommandPrefix.Length).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string cmd = parts.Length > 0 ? parts[0].ToLowerInvariant() : "";

            if (cmd == "solo")
            {
                string code = player.Game.Code.Value;
                bool next = !SoloModeLobbies.GetValueOrDefault(code, false);
                SoloModeLobbies[code] = next;
                await player.SendChatAsync(next ? "[Server] Solo Mode ON" : "[Server] Solo Mode OFF");
            }
            else if (cmd == "start")
            {
                await player.Game.SetGameStateAsync(GameState.Starting);
            }
            else if (cmd == "endgame")
            {
                await player.Game.SetGameStateAsync(GameState.Ended);
            }
            else if (cmd == "help")
            {
                await player.SendChatAsync("[Server] Commands: /solo, /start, /endgame, /help");
            }
        }
    }
}