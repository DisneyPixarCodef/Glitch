using System;
using System.Linq;
using System.Threading.Tasks;
using Impostor.Api.Events;
using Impostor.Api.Events.Meeting;
using Impostor.Api.Events.Player;
using Impostor.Api.Games;
using Impostor.Api.Innersloth;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TwoPlayerImmortal.Configuration;
using TwoPlayerImmortal.Services;

namespace TwoPlayerImmortal.Handlers
{
    public class GameFlowListener : IEventListener
    {
        private readonly ILogger<GameFlowListener> _logger;
        private readonly IOptionsMonitor<PluginConfig> _config;
        private readonly CustomGameCodeManager _codeManager;

        public GameFlowListener(ILogger<GameFlowListener> logger, IOptionsMonitor<PluginConfig> config, CustomGameCodeManager codeManager)
        {
            _logger = logger;
            _config = config;
            _codeManager = codeManager;
        }

        [EventListener(EventPriority.High)]
        public void OnGameCreation(IGameCreationEvent e)
        {
            e.GameCode = new GameCode(_codeManager.AllocateCode());
        }

        [EventListener]
        public void OnGameDestroyed(IGameDestroyedEvent e)
        {
            _codeManager.ReleaseCode(e.Game.Code.Value);
        }

        [EventListener(EventPriority.High)]
        public async ValueTask OnGameStarting(IGameStartingEvent e)
        {
            var game = e.Game;
            var players = game.Players.Where(p => p.Character != null).Select(p => p.Character!).ToList();

            if (players.Count == 2)
            {
                var host = players.FirstOrDefault(p => p.ClientPlayer?.IsHost == true) ?? players[0];
                var guest = players.FirstOrDefault(p => p != host) ?? players[1];

                host.PlayerInfo?.SetRole(RoleTypes.Impostor);
                guest.PlayerInfo?.SetRole(RoleTypes.Crewmate);
            }
            await ValueTask.CompletedTask;
        }
    }
}