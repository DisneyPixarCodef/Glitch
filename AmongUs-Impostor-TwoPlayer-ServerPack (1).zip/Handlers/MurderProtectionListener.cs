using System;
using System.Threading.Tasks;
using Impostor.Api.Events;
using Impostor.Api.Events.Player;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TwoPlayerImmortal.Configuration;

namespace TwoPlayerImmortal.Handlers
{
    public class MurderProtectionListener : IEventListener
    {
        private readonly ILogger<MurderProtectionListener> _logger;
        private readonly IOptionsMonitor<PluginConfig> _config;

        public MurderProtectionListener(ILogger<MurderProtectionListener> logger, IOptionsMonitor<PluginConfig> config)
        {
            _logger = logger;
            _config = config;
        }

        [EventListener]
        public async ValueTask OnPlayerMurder(IPlayerMurderEvent e)
        {
            if (!_config.CurrentValue.InfiniteShieldEnabled) return;

            var victim = e.Victim;
            if (victim.PlayerInfo != null && !victim.PlayerInfo.IsImpostor)
            {
                // Unbreakable server-side kill cancellation
                e.IsCancelled = true;

                _logger.LogInformation("Kill cancelled on Immortal Crewmate: {Victim}", victim.PlayerInfo.PlayerName);

                try
                {
                    await victim.RpcProtectPlayerAsync(victim);
                }
                catch { /* legacy client visual RPC fallback */ }
            }
        }
    }
}