using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TwoPlayerImmortal.Configuration;

namespace TwoPlayerImmortal.Services
{
    public class CustomGameCodeManager
    {
        public const string CharSet = "QWXRTYLPESDFGHUJKZOCVBINMA";

        private static readonly Dictionary<char, int> CharMap = CharSet
            .Select((c, i) => new { c, i })
            .ToDictionary(x => x.c, x => x.i);

        private readonly ILogger<CustomGameCodeManager> _logger;
        private readonly IOptionsMonitor<PluginConfig> _config;
        private readonly ConcurrentDictionary<string, byte> _activeCodes = new ConcurrentDictionary<string, byte>();
        private readonly Random _random = new Random();

        public CustomGameCodeManager(ILogger<CustomGameCodeManager> logger, IOptionsMonitor<PluginConfig> config)
        {
            _logger = logger;
            _config = config;
        }

        public static bool IsValidCode(string? code)
        {
            if (string.IsNullOrWhiteSpace(code) || code.Length != 6) return false;
            return code.ToUpperInvariant().All(c => CharMap.ContainsKey(c));
        }

        public static int V2ToInt(string code)
        {
            string upper = code.ToUpperInvariant();
            int a = CharMap[upper[0]], b = CharMap[upper[1]], c = CharMap[upper[2]];
            int d = CharMap[upper[3]], e = CharMap[upper[4]], f = CharMap[upper[5]];
            int firstTwo = a + 26 * b;
            int lastFour = c + 26 * (d + 26 * (e + 26 * f));
            return (firstTwo & 0x3FF) | ((lastFour & 0xFFFFF) << 10);
        }

        public static string IntToV2(int gameId)
        {
            int firstTwo = gameId & 0x3FF;
            int lastFour = (gameId >> 10) & 0xFFFFF;
            return new string(new[]
            {
                CharSet[firstTwo % 26],
                CharSet[(firstTwo / 26) % 26],
                CharSet[lastFour % 26],
                CharSet[(lastFour /= 26) % 26],
                CharSet[(lastFour /= 26) % 26],
                CharSet[(lastFour / 26) % 26]
            });
        }

        public string AllocateCode()
        {
            var cfg = _config.CurrentValue;
            string? candidate = null;

            if (cfg.CodeMode == "Suffix" && cfg.GlitchSuffixes != null && cfg.GlitchSuffixes.Count > 0)
            {
                string suffix = cfg.GlitchSuffixes[_random.Next(cfg.GlitchSuffixes.Count)];
                char c0 = CharSet[_random.Next(CharSet.Length)];
                char c1 = CharSet[_random.Next(CharSet.Length)];
                candidate = $"{c0}{c1}{suffix}";
            }

            if (candidate == null || _activeCodes.ContainsKey(candidate))
            {
                candidate = "REDSUS"; // Fallback safe code
            }

            _activeCodes.TryAdd(candidate, 1);
            return candidate;
        }

        public void ReleaseCode(string code) => _activeCodes.TryRemove(code.ToUpperInvariant(), out _);
    }
}