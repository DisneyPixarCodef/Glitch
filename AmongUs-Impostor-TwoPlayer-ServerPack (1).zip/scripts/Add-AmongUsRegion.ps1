# Windows Region Setup Script with Automatic Backup
param(
    [string]$ServerIp = "127.0.0.1",
    [int]$ServerPort = 22023,
    [string]$ServerName = "My Private Server"
)
$Folder = Join-Path $env:USERPROFILE "AppData\LocalLow\Innersloth\Among Us"
$File = Join-Path $Folder "regionInfo.json"
if (Test-Path $File) {
    Copy-Item $File "$File.bak_$(Get-Date -Format yyyyMMdd-HHmmss)" -Force
}
# Appends server to Regions and sets CurrentRegionIdx