using System.Collections.Generic;

namespace TwoPlayerImmortal.Configuration
{
    public class PluginConfig
    {
        public const string Section = "TwoPlayerImmortal";

        public int Port { get; set; } = 22023;
        public int MinimumPlayers { get; set; } = 2;
        public string ImposterSelection { get; set; } = "Host";
        public bool InfiniteShieldEnabled { get; set; } = true;
        public string WinConditionBehavior { get; set; } = "TasksAndMeetingsOnly";
        public bool AllowSabotageWins { get; set; } = true;
        public string CodeMode { get; set; } = "Suffix";
        public string FixedCode { get; set; } = "ABCDEF";
        public string CodeListPath { get; set; } = "codes.txt";
        public List<string> GlitchSuffixes { get; set; } = new List<string>
        {
            "XYZW", "GLTC", "HACK", "TEST", "AUGL", "ZERO"
        };
        public bool SoloModeEnabled { get; set; } = true;
        public string SoloCommandPrefix { get; set; } = "/";
        public bool HostOnlyCommands { get; set; } = true;
    }
}