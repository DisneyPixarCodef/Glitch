using System.Threading.Tasks;
using Impostor.Api.Events;
using Impostor.Api.Plugins;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TwoPlayerImmortal.Configuration;
using TwoPlayerImmortal.Handlers;
using TwoPlayerImmortal.Services;

namespace TwoPlayerImmortal
{
    [ImpostorPlugin(
        id: "org.custom.twoplayer",
        name: "TwoPlayerImmortal",
        author: "PrivateAmongUsServer",
        version: "1.0.0")]
    public class TwoPlayerPlugin : PluginBase
    {
        private readonly ILogger<TwoPlayerPlugin> _logger;
        private readonly IEventManager _eventManager;
        private readonly GameFlowListener _gameFlowListener;
        private readonly MurderProtectionListener _murderProtectionListener;
        private readonly ChatCommandListener _chatCommandListener;

        public TwoPlayerPlugin(
            ILogger<TwoPlayerPlugin> logger,
            IEventManager eventManager,
            GameFlowListener gameFlowListener,
            MurderProtectionListener murderProtectionListener,
            ChatCommandListener chatCommandListener)
        {
            _logger = logger;
            _eventManager = eventManager;
            _gameFlowListener = gameFlowListener;
            _murderProtectionListener = murderProtectionListener;
            _chatCommandListener = chatCommandListener;
        }

        public override ValueTask EnableAsync()
        {
            _logger.LogInformation("TwoPlayerImmortal Plugin v1.0.0 enabled!");
            _eventManager.RegisterListener(_gameFlowListener);
            _eventManager.RegisterListener(_murderProtectionListener);
            _eventManager.RegisterListener(_chatCommandListener);
            return ValueTask.CompletedTask;
        }

        public override ValueTask DisableAsync()
        {
            _eventManager.UnregisterListener(_gameFlowListener);
            _eventManager.UnregisterListener(_murderProtectionListener);
            _eventManager.UnregisterListener(_chatCommandListener);
            return ValueTask.CompletedTask;
        }
    }

    public class TwoPlayerPluginStartup : IPluginStartup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions<PluginConfig>()
                .Configure<IConfiguration>((options, configuration) =>
                {
                    configuration.GetSection(PluginConfig.Section).Bind(options);
                });

            services.AddSingleton<CustomGameCodeManager>();
            services.AddSingleton<GameFlowListener>();
            services.AddSingleton<MurderProtectionListener>();
            services.AddSingleton<ChatCommandListener>();
        }
    }
}