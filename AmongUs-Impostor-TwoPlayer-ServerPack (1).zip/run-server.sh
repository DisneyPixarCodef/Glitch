#!/bin/bash
set -e
echo "====================================================="
echo " Starting Impostor Server with TwoPlayerImmortal... "
echo "====================================================="

# Download latest Impostor server if not present
if [ ! -f "./Impostor.Server" ]; then
  echo "[+] Downloading Impostor Server binary..."
  curl -sSL -o impostor.tar.gz https://github.com/Impostor/Impostor/releases/download/v1.10.0/Impostor-Server-v1.10.0-linux-x64.tar.gz || true
  if [ -f impostor.tar.gz ]; then
    tar -xzf impostor.tar.gz
    chmod +x Impostor.Server
  fi
fi

# Build plugin
echo "[+] Building TwoPlayerImmortal C# plugin (.NET 8)..."
dotnet publish -c Release -o plugins/TwoPlayerImmortal

# Run
echo "[+] Running Impostor on port 22023 (UDP & TCP)..."
./Impostor.Server || dotnet run
