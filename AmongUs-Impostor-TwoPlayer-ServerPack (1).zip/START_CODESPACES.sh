#!/bin/bash
set -e
echo "=========================================================="
echo " Starting Among Us Impostor Server in GitHub Codespaces  "
echo "=========================================================="

echo "[1/2] Building and starting Docker container..."
docker compose up -d --build

echo "[2/2] Launching Playit UDP tunnel for mobile connection..."
if ! command -v playit &> /dev/null; then
    echo "Installing Playit..."
    curl -SsL https://playit-cloud.github.io/ppa/key.gpg | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/playit.gpg >/dev/null
    echo "deb [signed-by=/etc/apt/trusted.gpg.d/playit.gpg] https://playit-cloud.github.io/ppa/data ./" | sudo tee /etc/apt/sources.list.d/playit.list >/dev/null
    sudo apt update -qq && sudo apt install -qq playit -y
fi

echo "=========================================================="
echo "Playit startet gleich. Klicke auf den angezeigten Link, um"
echo "den Tunnel kostenlos mit deinem Handy zu verbinden!"
echo "=========================================================="
playit
